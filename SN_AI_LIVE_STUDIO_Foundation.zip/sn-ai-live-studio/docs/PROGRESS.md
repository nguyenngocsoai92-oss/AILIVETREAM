# Tiến độ — 22/11/2026

| Mã | Phân hệ | Yêu cầu | Trạng thái | File | Cập nhật | Ưu tiên | Phụ thuộc | Kết quả kiểm thử | Tồn đọng | Tiếp theo |
|---|---|---|---|---|---|---|---|---|---|---|
| INIT-01 | Sản phẩm/kiến trúc | PRD, kiến trúc, DB, tài liệu và lộ trình | Implemented | AGENTS.md, README.md, docs/*.md | 22/11/2026 | P0 | Đặc tả gốc | Kiểm tra tệp, liên kết nội bộ và ZIP | Chưa có repo dự án, gh CLI chưa xác thực | Tạo hoặc kết nối repo của SN |
| INIT-02 | Tích hợp | Rà tài liệu chính thức | In Progress | INTEGRATION_MATRIX.md | 22/11/2026 | P0 | Tài liệu công khai, quyền SN | Đối chiếu tài liệu công khai. Chưa có thử nghiệm tài khoản thật | Thiếu ứng dụng đối tác, phạm vi, quota và sandbox ERP | INT-01 và khảo sát ERP |
| FND-01 | Desktop | Bootstrap Electron/React/TS | Not Started | apps/desktop | 22/11/2026 | P0 | Repository và mốc V0.1 được chốt | Chưa chạy | GitHub CLI chưa xác thực | Khởi tạo repo, xác nhận máy kiểm thử |
| FND-02 trở đi | Các phân hệ | Theo từng mã nghiệm thu | Not Started | MASTER_CHECKLIST.md | 22/11/2026 | Theo checklist | Theo checklist | Chưa chạy | Chưa có mã ứng dụng | Cập nhật theo từng mã khi khởi động |

Trạng thái chuẩn gồm Not Started → In Progress → Implemented → Tested → Verified → Released.
Môi trường khảo sát Linux x86_64, Node 24.22.3, npm 11.19.1, Git 2.56.1 và GitHub CLI có sẵn. GitHub chưa xác thực. Cần macOS/Windows native để nghiệm thu bộ cài.
